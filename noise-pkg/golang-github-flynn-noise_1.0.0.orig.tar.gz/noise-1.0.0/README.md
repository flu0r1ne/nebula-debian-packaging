# noise [![Go Reference](https://pkg.go.dev/badge/github.com/flynn/noise.svg)](https://pkg.go.dev/github.com/flynn/noise) [![CI Status](https://github.com/flynn/noise/actions/workflows/ci.yml/badge.svg)](https://github.com/flynn/noise/actions)

This is a Go package that implements the [Noise Protocol
Framework](https://noiseprotocol.org). See [the
documentation](https://pkg.go.dev/github.com/flynn/noise) for usage information.
